## ESP_CapSense library
To install, download this folder and move the files into a folder named "ESP_CapSense" inside the ```Arduino>libraries``` folder.

Then, restart Arduino IDE. You should now be able to use this library by adding ```#include <ESP_CapSense.h>``` at the top of a sketch.
